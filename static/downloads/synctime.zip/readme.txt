Standardm��ig synchronisiert das Programm mit dem Timeserver ntps1-1.uni-erlangen.de

Alternativ kann ein anderer Server per Parameter angegeben werden:

synctime [Server]